
let countNum = 0;
const clicker = () => {
    const el = document.getElementById("counter");
    countNum += 1;
    el.innerText = countNum;
}
